import Link from 'next/link';

export default function Layout(props) {

  return (
    <>
      <div style={{ padding: "10px" }}>
        <h2>Online Shopping</h2>
        <Link href="/"><a>Home</a></Link> | <Link href="/products"><a>Products</a></Link> | <Link href="/cart"><a>Shopping Cart</a></Link>
        <hr />
        {props.children}
      </div>
    </>
  )
}

