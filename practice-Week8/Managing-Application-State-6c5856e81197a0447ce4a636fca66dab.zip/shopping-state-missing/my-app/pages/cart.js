export default function Cart() {

  return (
    <>
      Cart
    </>
  )
}
