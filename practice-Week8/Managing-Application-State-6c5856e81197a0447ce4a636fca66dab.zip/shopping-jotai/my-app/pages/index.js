export default function Home() {
  return (
    <>
      <h3>Shopping Cart Demo</h3>
      <p>This site demonstrates application state management in React</p>
    </>
  )
}
